const AWS = require('aws-sdk');
const uuid = require('uuid');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const data = JSON.parse(event.body);
    const params = {
        TableName: 'Thoughts',
        Item: {
            ThoughtID: uuid.v4(),
            Content: data.content,
            Timestamp: Date.now()
        },
    };

    try {
        await dynamoDb.put(params).promise();
        return { statusCode: 200, body: JSON.stringify(params.Item) };
    } catch (error) {
        return { statusCode: 500, body: JSON.stringify(error) };
    }
};
